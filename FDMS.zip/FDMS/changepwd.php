<?php 

	session_start();
    require_once('config.php'); 

	$pass=$_POST['changepwd'];
	$password=base64_encode($pass);
	// $password=$pass;

	$result = mysqli_query($con,("SELECT Username FROM login WHERE UserName ='".$_SESSION['username']."'"));

	if(mysqli_num_rows($result) > 0 )
  { 

	$sql = "UPDATE `login` SET `Password`='".$password."' WHERE Username ='".$_SESSION['username']."' " ;
	
	 	 	
	if($con->query($sql))
	  {   
	    echo "1";
	  }
	  else{
	     echo "Error: " . $sql . "<br>" . $con->error;
	  }

	}else{
		 $sql = "INSERT INTO `Project_Time_Tracker_Login` (`Username`, `Password`) VALUES ('".$_SESSION['username']."', '$password')";

      if($con->query($sql))
      {   
        echo "1";
      }else{
      	echo "Error: " . $sql . "<br>" . $con->error;
      }
	}
?>
