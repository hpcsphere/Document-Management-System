<?php
  session_start();
  require_once('config.php');

  $user = "";
  $email = "";
  if(isset($_SESSION['username'])){
    $user=$_SESSION['username'];
  }else{
    header("Location: login.html");
  }

?>




<!DOCTYPE html>
<html>
<head>
  <title>Document Processing and Management System</title>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/png" href="icon.png">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/pdp.css">
  <link href="css/dropzone.css" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/dropzone.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pretty-checkbox@3.0/dist/pretty-checkbox.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.css" rel="stylesheet"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.js"></script>
</head>

<style>
  .chosen-container-single .chosen-default{ text-align: left; }

  .chosen-container .chosen-results { text-align: left; }

  .chosen-container {
    text-align: left;
    width: 300px ! important;
  }
  
  body { width: 100%; }

  .load {
    font-size: 90px;
    position: absolute;
    margin-top: 150px;
    margin-left: 490px;
    display: none;
    z-index: 100;
  }

  .lricon {
    position: absolute;
    left: 192px;
    font-size: 33px;
    top: 190px;
    color: #87CEEB !important;
    cursor: pointer;
  }

  .dropzone1 {
    border: 1px solid rgba(0, 0, 0, 0.3);
    height: auto;
    background: radial-gradient(ellipse at center,#fff 0,#fff 100%);
  }

  .dropzone1.dz-clickable .dz-message, .dropzone.dz-clickable .dz-message * {
    cursor: pointer;
  }

  .dropzone1 .dz-message {
    text-align: center;
    margin: 2em 0;
  }

  .dropzone1.dz-clickable * {
    cursor: default;
  }

  .dropzone1, .dropzone * {
    box-sizing: border-box;
  }

  .txt {
    color: #87CEEB;
    font-size: 14px;
  }

  .info {
    color: #87CEEB ! important;
    font-size: 13px;
    cursor: pointer;
    position: relative;
  }

  .table>caption+thead>tr:first-child>td, .table>caption+thead>tr:first-child>th, .table>colgroup+thead>tr:first-child>td, .table>colgroup+thead>tr:first-child>th, .table>thead:first-child>tr:first-child>td, .table>thead:first-child>tr:first-child>th {
    border: none;
  }

  table.dataTable.no-footer {
    border: none;
  }

  table.dataTable thead th, table.dataTable thead td {
    padding-left: 7px;
  }

</style>

 <body class="fa">
     <header style="background-color: #87CEEB;padding: 10px;position: fixed;width: 100%;height: 15px;z-index: 100;"> 
      <div style="float: right;position: relative;bottom: 12px;">
        <a href="setting.php"><i class="fa fa-cog" title="Settings" style="padding: 5px;color: white ! important;cursor: pointer;"></i></a>
         <a href="logout.php"><i class="fa fa-power-off" title="Logout" style="padding: 5px;color: white ! important;cursor: pointer;"></i></a>
       </div>
    </header> 
      <div class="container container1">
        <center> <h3 class="effect">Document Processing and Management System</h3></center>
    </div><br>

     <div class="sidebar">

        <ul class="sidebar-nav">


             <i id="navbar-toggle" class="fa fa-times menu-icon fa-2x open" id="open" aria-hidden="true" style="color: white !important;margin: 6px;margin-right: -25px;cursor: pointer;background-color: rgb(135, 206, 235) !important;width: 25px;margin-top: 0px;padding-left: 4px;position: absolute;right: 0;display: none;border-left: 1px solid white;" title="Open"></i>

            <i id="navbar-toggle" class="fa fa-arrow-left menu-icon fa-2x closem" id="closem" aria-hidden="true" style="color: white !important;margin: 6px;margin-right: -25px;cursor: pointer;background-color: rgb(135, 206, 235) !important;width: 25px;margin-top: 0px;padding-left: 4px;position: absolute;right: 0;border-left: 1px solid white;font-size: 17px;height: 20px;" title="Close"></i>

              <i id="navbar-toggle" class="fa fa-bars menu-icon fa-2x closem1" id="closem1" aria-hidden="true" style="color: white !important;margin: 6px;margin-right: -25px;cursor: pointer;background-color: rgb(135, 206, 235) !important;width: 25px;margin-top: 0px;padding-left: 4px;position: absolute;right: 0;display:none ;border-left: 1px solid white;z-index: 100;" title="Close"></i>

            <li>
                <a href="./" class="active"><i class="fa fa-cloud-upload menu-icon fa-2x" aria-hidden="true" style="color: white !important;line-height: 0.2;font-size: 20px;float: ;"></i>&nbsp;&nbsp;Upload Documents</a>
                <a href="setting.php"><i class="fa fa-cog menu-icon fa-2x" aria-hidden="true" style="color: white !important;line-height: 0.2;font-size: 20px;float: ;"></i>&nbsp;&nbsp;Settings</a>
            </li>

        </ul>
    </div>



    <div class="container col-sm-12">
      <div class="col-sm-12 paddleft" style=";padding-left: 220px;">

         <center style="position: relative;right: 85px;">
           <label class="txt">Select a bucket to upload file</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <select data-placeholder="Select a Bucket" class="chosen-select fa" tabindex="2" style="">
             <option value=""></option>
            <?php
               $sql = "SELECT * FROM Buckets WHERE 1";
               $result=$con->query($sql);

                if (mysqli_num_rows($result) > 0) {
                  while($row = mysqli_fetch_assoc($result)) {
                    if($row['Status']=="default"){
                      echo"<option selected value='".$row['Bucket_Name']."'>".$row['Bucket_Name']." ( ".$row['SN']." )</option>";
                    }else{
                      echo"<option value='".$row['Bucket_Name']."'>".$row['Bucket_Name']." ( ".$row['SN']." )</option>";
                    }
                  }

               }

              ?>
           
          </select>&nbsp;
          <i class="fa fa-info-circle info"></i>
        </center>

        <br>

        <form  action="upload2.php" class="dropzone" name="" style="overflow: auto; min-height:155px; max-height:155px;display: none;"> </form>

        <form action="upload2.php" class="dropzone1" name="" style="overflow: auto; min-height:155px; max-height:155px;cursor: not-allowed;"> <div class="dz-default dz-message"><span style="position:relative;top:5px;"> <i class="fa fa-cloud-upload" style="color:#87CEEB ! important; font-size:60px;"></i><p style="color:white;">Drop files here to upload</p></span></div></form>

      </div>

      <div class="col-sm-12 paddleft" style="margin-top: 30px;margin-bottom: 30px;padding-left: 220px;">

        <i class="fa  fa-spinner fa-spin load"></i>

        <div class="list" style="overflow: auto; min-height:400px; max-height:400px;padding: 20px;">
        </div>
      </div>
  
    </div>

    <!-- Modal -->
  <div class="modal fade" id="detailsmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <center> <h4 class="modal-title" style="font-family: bold;float: left;"><b>Document Processing and Management System</b></h4></center>
        </div>
        <div class="modal-body">
            <table class="table">
                <tbody>
                  <tr>
                    <td style="border-top: none;">Name</td>
                    <td id="filename" style="border-top: none;"></td>
                  </tr>
                  <tr>
                      <td>Last modified date</td>
                     <td id="lmd"></td>
                  </tr>
                  <tr>
                    <td>File size</td>
                    <td id="filesize"></td>
                  </tr>
                  <tr>
                    <td>Etag</td>
                    <td id="etag"></td>
                  </tr>
                  <tr>
                    <td>Storage class</td>
                    <td id="storageclass"></td>
                  </tr>
                </tbody>
              </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="infomodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <center> <h4 class="modal-title" style="font-family: bold;float: left;"><b>Document Processing and Management System</b></h4></center>
        </div>
        <div class="modal-body">
           You can set the default bucket in the settings page.
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

   <!-- Change Password Modal -->
    <div id="chngpassmdl" class="modal">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Change Password</h4>
          </div>
          <div class="modal-body">
            <form id="chngpassfrm">
              <input type="Password" name="Password" class="form-control" placeholder="Enter New Password" id="newpass" required style="margin-top: 15px;">
              <input type="Password" name="Password" class="form-control" placeholder="Confirm Password" id="confrmpass" required style="margin-top: 15px;">
              <center><button class="btn btn-primary" id="chngpassbtn" style="margin-top: 15px;"><i class="fa fa-check" style="color: white ! important;"></i><i class="fa fa-spinner fa-spin spin" style="font-size: 28px;position: absolute;margin-top: -3px;display:none ; color: white ! important;"></i>&nbsp;Save</button></center>
            </form>
          </div>
          <div class="modal-footer">
            <p style="color: green ! important;position: absolute;left: 17px;display:none ;" id="pc"><i class="fa fa-check"></i>&nbsp;Password Changed Successfully.</p>
            <p style="color: red ! important;position: absolute;left: 17px;display: none;" id="pnc"><i class="fa fa-times"></i>&nbsp;Password Not Change!</p>
        <button type="button" class="btn btn-default cl" data-dismiss="modal" style="border: 1px solid lightgrey;"><i class="fa fa-times"></i>&nbsp; Close</button>
          </div>
        </div>

      </div>
    </div>



     <!-- Modal -->
  <div class="modal fade" id="bucketsmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <center> <h4 class="modal-title" style="font-family: bold;float: left;"><b>Document Processing and Management System</b></h4></center>
        </div>
        <div class="modal-body">
           Kindly select bucket name.
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>



  <div class="modal fade" id="deleteModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <center> <h4 class="modal-title" style="font-family: bold;float: left;"><b>Document Processing and Management System</b></h4></center>
        </div>
        <div class="modal-body">
        <span style="display:inline-block; float:left;font-size:15px">Are you sure you want to delete</span>&nbsp;
        <span id= "filenameD" style="font-size:15px"></span>&nbsp;<span style="font-size: 15px;">?</span>
         <span id= "filenameD1" style="font-size:15px;display: none;"></span>
           <div>
           </div>
        </div>
        <div class="modal-footer">
        <span style="color: green;display: none;" id="sd">Succefully deleted</span>
        <span style="color: red;display: none;" id="nsd">Not deleted</span>
        &nbsp;&nbsp;&nbsp;
        <button type="button" class="btn btn-success" id="deleteBtn"><i class="fa fa-check"  style="color: white ! important;"></i>&nbsp; Yes &nbsp;<i class="fa fa-spinner fa-spin" style="color: white ! important;display:none ;" id="dload"></i></button>
        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" style="color: white ! important;"></i>&nbsp; No</button>
        </div>
      </div>
      
    </div>
  </div>
  
    <script>

    var bucket = "";

    $("body").delegate(".details","click",function(){

      $("#filename").text($(this).siblings(".keyn").text());
      var mydate = $(this).siblings(".lmd").text();
      $("#lmd").text(mydate);
      $("#filesize").text($(this).siblings(".filesize").text());
      $("#etag").text($(this).siblings(".etag").text());
      $("#storageclass").text($(this).siblings(".storageclass").text());

      $("#detailsmodal").modal();
    });

     $("body").delegate(".trash","click",function(){
      $("#filenameD").text($(this).siblings(".keyn").text());
      $("#filenameD1").text($(this).siblings(".keyn1").text());
      $("#deleteModal").modal();
    });


      $("#deleteBtn").click(function(){
      
      var selectedBucket = $('.chosen-select').val();
      var deleteFile = document.getElementById("filenameD1").innerText;

      $(this).attr("disabled",true);
      $("#dload").css("display","inline-block");

      $.post( "delete_file.php", { bucket: selectedBucket, keyname: deleteFile}, function( data ) {
        $("#sd").fadeIn(1000).fadeOut(6000);
         $(this).attr("disabled",false);
          $("#dload").css("display","none");
          $('#deleteModal').modal('toggle');
        fetchBucket(selectedBucket);
      });
    }); 

  
  $("#chng").click(function(){
    $("#chngpassmdl").modal();
  });

  $("#chngpassfrm").submit(function(e){
    e.preventDefault();
    var newpass = $("#newpass").val();
    var confrmpass = $("#confrmpass").val();
    if(confrmpass !== newpass){
      $("#confrmpass").css("border","1px solid red");
    }else{
      $("#chngpassbtn").attr("disabled",true);
      $("#chngpassbtn").css("cursor","not-allowed");
      $(".spin").css("display","inherit");
      $("#confrmpass").css("border","1px solid lightgrey");
      $.post('changepwd.php',{
        'changepwd' : confrmpass,
      },function(data){
        if(data==1){
          $("#chngpassbtn").removeAttr("disabled");
          $("#chngpassbtn").css("cursor","pointer");
          $(".spin").css("display","none");
          $("#pc").fadeIn(1500).fadeOut(4000);
        }else{
          $("#chngpassbtn").removeAttr("disabled");
          $("#chngpassbtn").css("cursor","pointer");
          $(".spin").css("display","none");
          $("#pnc").fadeIn(1500).fadeOut(4000);
        }
      });
    }
  }); 


  if(getCookie("nav")=="open"){
     var state = "expanded";
    $('.sidebar').css('margin-left', '0px');
     $(".paddleft").css({ "padding-left": "220px"});
     $(".lricon").css({ "left": "192px"}); 
     $(".closem").css("display","inline-block");
     $(".open").css("display","none");
     $(".sidebar").css("transition","none");
  }else if(getCookie("nav")=="close"){
   
    $(".sidebar").css("transition"," none");
     // var state = "minimized";
     var state = "minimized";
    $('.sidebar').css('margin-left', '-150px');
    $(".paddleft").css({ "padding-left": "70px"}); 
    $(".lricon").css({ "left": "42px"}); 
    $(".open").css("display","inline-block");
    $(".closem").css("display","none");
    $(".closem1").css("display","none");
  }else{
    $(".sidebar").css("transition"," none");
    $('.sidebar').css({'margin-left':'-202px'});
     $(".closem1").css("display","inline-block");
     $(".paddleft").css({ "padding-left": "8px"}); 
     var state = "minimized1";
   
  }

//Check if navbar is expanded or minimized and handle 
$('.closem, .closem1, .open').click(function() {
  $(".sidebar").css("transition","margin 1s");
  if($(this).hasClass("open")){
    setCookie("nav","close1");
  }else if($(this).hasClass("closem")){
    setCookie("nav","close");
  }else{
    setCookie("nav","open");
  }

  


    if (state == "expanded") {
        $('.sidebar').css('margin-left', '-150px');
        // state = "minimized";
        $(".paddleft").animate({ "padding-left": "70px"}, 1000); 
        $(".lricon").animate({ "left": "42px"}, 760); 
        $(".open").css("display","inline-block");
        $(".closem").css("display","none");
        state = "minimized";
    } else {
        if (state == "minimized") {
            state = "minimized1";

          $(".closem1").css("display","inline-block");
          $('.sidebar').css({'margin-left':'-202px'});
          $(".paddleft").animate({ "padding-left": "8px"}, 1000); 
        }else{
          $(".closem").css("display","block");
           $(".closem1").css("display","none");
           $('.sidebar').css({'margin-left':'0px'});
           $(".paddleft").animate({ "padding-left": "220px"}, 1000);
           $(".lricon").animate({ "left": "192px"}, 760); 
          
          state = "expanded";

        }
    }
})


 $(document).ready(function() {
        $(function() {
        $('.chosen-select').chosen();
        $('.chosen-select-deselect').chosen({ allow_single_deselect: true });
      });

        $("body").delegate(".active-result").addClass("fa");
});


$.post('insert_bucket.php',{
},function(data){
 
});

$(".chosen-select").change(function(){
  bucket = $(this).val();
  $(".dropzone1").css("display","none");
  $(".dropzone").css("display","block");
  $(".load").css("display","inline-block");
  $(".list").css("opacity","0.2");
  fetchBucket(bucket);
});


if($(".chosen-select").val()=="" || $(".chosen-select").val() ==null){
    $(".dropzone1").css("display","block");
    $(".dropzone").css("display","none");
  }else{
    bucket = $(".chosen-select").val();
    $(".dropzone1").css("display","none");
    $(".dropzone").css("display","block");
    $(".load").css("display","inline-block");
    $(".list").css("opacity","0.2");
    fetchBucket(bucket);
  }


  function setCookie(key, value, expiry) {
        var expires = new Date();
        expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
        document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
    }

    function getCookie(key) {
        var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
        return keyValue ? keyValue[2] : null;
    }

    function fetchBucket (bucket) {
       $.post('fetch_buckets.php',{
        'bucket' : bucket,
        },function(data){
          $(".list").html(data);
            $('#table').DataTable( {
                "order": [[ 1, "asc" ]]
            });
          $(".load").css("display","none");
           $(".list").css("opacity","1");
        });
    }


    $(".info").click(function(){
      $("#infomodal").modal();
    });

    </script>
  

  </body>
  </html>