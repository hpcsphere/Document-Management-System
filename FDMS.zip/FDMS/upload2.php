<?php 

require_once('config.php');

 $key = "";
 $secret = "";

  $sql1 = "SELECT * FROM Bucket_Credentials WHERE 1";
  $result1=$con->query($sql1);
   if (mysqli_num_rows($result1) > 0) {
      while($row = mysqli_fetch_assoc($result1)) {
        $key = $row['key'];
        $secret = $row['secret'];
      }
    }
                        
if(isset($_FILES['file'])){
        $file_name = $_FILES['file']['name'];   
        $temp_file_location = $_FILES['file']['tmp_name']; 

        require 'vendor/autoload.php';

        $s3 = new Aws\S3\S3Client([
            'region'  => 'us-east-2',
            'version' => 'latest',
            'credentials' => [
                'key'    => $key,
                'secret' => $secret,
            ]
        ]);     

        $result = $s3->putObject([
            'Bucket' => $_POST['bucket'],
            'Key'    => $file_name,
            'SourceFile' => $temp_file_location         
        ]);

        // var_dump($result);

    }



?>


