<?php
require 'vendor/autoload.php';
require_once('config.php');

  $key = "";
  $secret = "";

  $sql1 = "SELECT * FROM Bucket_Credentials WHERE 1";
  $result1=$con->query($sql1);
   if (mysqli_num_rows($result1) > 0) {
      while($row = mysqli_fetch_assoc($result1)) {
        $key = $_POST['key'];
        $secret = $_POST['secret'];
      }
    }

    use Aws\S3\S3Client;  
    use Aws\Exception\AwsException;
    try{
          //Create a S3Client 
        $s3Client = new S3Client([
            'region' => 'us-east-2',
            'version' => 'latest',
              'credentials' => [
                      'key' => $key,
                      'secret' =>  $secret,
                      ]
                  ]);

        //Listing all S3 Bucket
        $buckets = $s3Client->listBuckets();
        foreach ($buckets['Buckets'] as $bucket) {
           $sqls="SELECT * from `Buckets` WHERE `Bucket_Name` = '".$bucket['Name']."'";
          $results = $con->query($sqls);
          if ($results->num_rows == 0)
          {
            $sql = "INSERT INTO `Buckets`( Bucket_Name) VALUES ('".$bucket['Name']."')";
            $result=$con->query($sql);
          }
        }
      }
    catch(S3Exception $e){
      echo $e->getMessage(). "\n";

    } 

?>