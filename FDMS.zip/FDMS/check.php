<?php
session_start();
  // if (isset($_POST['submit']))
	 // {	  
     require_once('config.php'); 

      

      $username=$_POST['username'];
      // $password=$_POST['password'];

      $password=$_POST['password'];
     
      // $_SESSION['login_user']=$username;
 
      $result = mysqli_query($con,("SELECT * FROM `login` WHERE Username= '$username' and Password = '$password' "));
    
      if(mysqli_num_rows($result) > 0 )
            { 
                 $_SESSION['username']=$username;

                  // echo "<script language='javascript' type='text/javascript'> location.href='index1.php' </script>"; 
                 echo '1';
            }else
              {
                 // echo "<script type='text/javascript'>alert('User Name Or Password Invalid!')</script>";
                echo '2';

                echo "Error: " . $result . "<br>" . $con->error;
               }
             // }
    
?>