
$(document).ready(function(){

  $("#submit").click(function(){

   var from = $("#From").val();
   var cc = $("#cc").val();
   var subject = $("#subject").val();
   var content=$("iframe").contents().find("body").html();
   var wee = $("#wee").val();
   console.log("wee",wee);

   console.log("from",from);
   console.log("to",to);
   console.log("cc",cc);
   console.log("subject",subject);
   console.log("content",content);

   if(from=="" || from==null || subject=="" || subject==null){
     $("#notsuccessmodal").modal();
   }else{

    if(validateEmail(from)) {
      $("#From").css("border", "1px solid lightgrey");

      if(cc=="" || cc==null){
        $("#spin").css("display","initial");
      $(this).attr("disabled",true);
        
        $.post('mail.php',{
      'from':from,
      'cc':cc,
      'subject':subject,
      'content':content,
      'wee':wee,
    },function(data){

      $("#successmodal").modal();
      $("#spin").css("display","none");
      $("#submit").attr("disabled",false);
    });



      }else{

        if(validateEmail(cc)) {
          $("#spin").css("display","initial");
          $(this).attr("disabled",true);
         $("#cc").css("border", "1px solid lightgrey");

           $.post('mail.php',{
      'from':from,
      'cc':cc,
      'subject':subject,
      'content':content,
      'wee':wee,
    },function(data){

      $("#successmodal").modal();
      $("#spin").css("display","none");
      $("#submit").attr("disabled",false);
    });

        }else{

          $("#cc").css("border","1px solid red");

        }

      }
         
      }else{
        $("#From").css("border","1px solid red");
      }

  }



  });

  $("#done").click(function(){

    $("#myModal").modal();

      $('html, body').animate({
        scrollTop: $("#editor").offset().top
      }, 900);

  });


  $("#wee").focusout(function(){

    var root = $(this).val();
    console.log(root);

    if(root=="E"){

      $(this).css({"background-color":"red","color":"white"});
    }else if (root=="WE") {
      $(this).css({"background-color":"green","color":"white"});
    }

  });

  $("#v").focusout(function(){

    var ver = $(this).val();
    console.log(ver);

    if(ver == "01"){
      $("iframe").contents().find("#changess").css("display","none");
    }else {
      $("iframe").contents().find("#changess").css("display","initial");
    }

  });


// $('#none').change(function () {
//     $('.check').prop('checked',this.checked);
// });

// $('.check').change(function () {
//  if ($('.check').length == $('.check').length){
//   $('#none').prop('checked',true);
//  }
//  else {
//   $('#none').prop('checked',false);
//  }
// });


function validateEmail(sEmail) {
   var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
   if (filter.test(sEmail)) {
      return true;
    }else {
      return false;
    }
  }




  tinymce.init({selector: '#mytextarea',
  plugins: "save ,pagebreak ,searchreplace, hr, fullpage, fullscreen, preview, code, table,importcss",
  toolbar: "save ,pagebreak ,searchreplace, fullpage, preview, code,table",
  pagebreak_split_block: true
  });



});