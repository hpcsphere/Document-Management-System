<?php
session_start();
require_once('config.php');


	$bcn=$_POST['bcn'];

	$sql1= "Update `Buckets` Set `Status` = null WHERE 1";
	$con->query($sql1);
		

	$sql= "Update `Buckets` Set `Status` = 'default' WHERE `SN` ='".$bcn."'";
	$con->query($sql);
	if ( $con->affected_rows !== 0) {
		echo "Successfully Set";
	}
		
?>
