<?php
require 'vendor/autoload.php';
require_once('config.php');

$key = "";
 $secret = "";

$sql1 = "SELECT * FROM Bucket_Credentials WHERE 1";
$result1=$con->query($sql1);
if (mysqli_num_rows($result1) > 0) {
  while($row = mysqli_fetch_assoc($result1)) {
    $key = $row['key'];
    $secret = $row['secret'];
  }
}


use Aws\S3\S3Client;

use Aws\S3\Exception\S3Exception;
$bucket = $_POST['bucket'];
$keyname = $_POST['keyname'];
$s3 = (new \Aws\Sdk)->createMultiRegionS3(['version' => 'latest']);
// Instantiate the client.
$s3 = new \Aws\S3\S3MultiRegionClient([
        'region' => 'us-west-2',
        'version' => 'latest',
        'credentials' => [
            'key'    => $key,
            'secret' => $secret,
        ]
    ]);     

// 1. Delete the object from the bucket.

try
{
    echo 'Attempting to delete ' . $keyname . '...' . PHP_EOL;

    $result = $s3->deleteObject([
        'Bucket' => $bucket,
        'Key'    => $keyname
    ]);

    if ($result['DeleteMarker'])
    {
        echo $keyname . ' was deleted or does not exist.' . PHP_EOL;
    } else {
        exit('Error: ' . $keyname . ' was not deleted.' . PHP_EOL);
    }
}
catch (S3Exception $e) {
    exit('Error: ' . $e->getAwsErrorMessage() . PHP_EOL);
}

// 2. Check to see if the object was deleted.

try
{
    echo 'Checking to see if ' . $keyname . ' still exists...' . PHP_EOL;

    $result = $s3->getObject([
        'Bucket' => $bucket,

        'Key'    => $keyname
    ]);

    echo 'Error: ' . $keyname . ' still exists.';
}
catch (S3Exception $e) {
    exit($e->getAwsErrorMessage());
} 
