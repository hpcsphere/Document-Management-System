<?php

$arr=[];

$username="";
session_start();

  if(isset($_SESSION['username'])){
    $username= $_SESSION['username'];
  }else{
    header("Location: login.html");
  }
 

	if($_FILES["file"]["name"] != '')
{
	$dir="upload/".$username;

	if (!file_exists($dir)) {
	   mkdir($dir, 0777);
		$target_path = $username."/";

		 $newFilename = $_FILES["file"]["name"];
	 	$location = 'upload/'.$target_path. $newFilename; 
	 	$wait = 'Waiting for Approval'; 
		move_uploaded_file($_FILES["file"]["tmp_name"], $location);
		array_push($arr, $newFilename);

	}else{


			$target_path = $username."/";	

		 $newFilename = $_FILES["file"]["name"];
	 	$location = 'upload/'.$target_path. $newFilename; 
	 	$wait = 'Waiting for Approval'; 
		move_uploaded_file($_FILES["file"]["tmp_name"], $location);
		array_push($arr, $newFilename);
	}


}


echo (json_encode($arr));
?>