<?php
require_once('config.php');

$key = $_POST['key'];
$secret = $_POST['secret'];

$sqls="SELECT * from `Bucket_Credentials` WHERE 1";
$results = $con->query($sqls);
if ($results->num_rows == 0)
{
  $sql = "INSERT INTO `Bucket_Credentials`(`key`, `secret`) VALUES ('".$key."','".$secret."')";
}else{
  $sql = "UPDATE `Bucket_Credentials` SET `key`='".$key."',`secret`='".$secret."'";
}

if($con->query($sql))
    {   
      echo "1";
      $sqls1="DELETE FROM `Buckets` WHERE 1";
      $con->query($sqls1);
      require_once('insert_bucket.php');
    }
    else{
       echo "Error: " . $sql . "<br>" . $con->error;
    }

?>