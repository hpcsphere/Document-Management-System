-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 29, 2019 at 02:22 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hpcspher_hpcs_official`
--

-- --------------------------------------------------------

--
-- Table structure for table `projectsdetailtable`
--

CREATE TABLE `projectsdetailtable` (
  `Sl.No` int(11) NOT NULL,
  `ProjectName` varchar(500) NOT NULL,
  `ProjectLink` varchar(500) NOT NULL,
  `Description` varchar(2500) NOT NULL,
  `ClientName` varchar(500) NOT NULL,
  `HpcsClientId` int(50) NOT NULL,
  `ClientProfileLink` varchar(500) NOT NULL,
  `ClientSkypeId` varchar(500) NOT NULL,
  `ClientEmailId` varchar(500) NOT NULL,
  `ClientMobNo` varchar(500) NOT NULL,
  `ClientWhatsapp` varchar(500) NOT NULL,
  `ClientCompanyName` varchar(500) NOT NULL,
  `ClientCountry` varchar(500) NOT NULL,
  `ProjectCost` varchar(500) NOT NULL,
  `ProjectCostCurrency` varchar(500) NOT NULL,
  `PaymentMethod` varchar(500) NOT NULL,
  `ProjectStatus` varchar(500) NOT NULL,
  `ProjectID` varchar(500) NOT NULL,
  `ProjectSource` varchar(500) NOT NULL,
  `SourceAccountID` varchar(500) NOT NULL,
  `StartDate` date DEFAULT NULL,
  `DueDate` date DEFAULT NULL,
  `ProjectCompletionDate` date DEFAULT NULL,
  `Comments` varchar(1000) DEFAULT NULL,
  `PaymentStatus` varchar(255) DEFAULT NULL,
  `Assignee1` varchar(500) NOT NULL,
  `Percentage1` varchar(4) DEFAULT NULL,
  `Assignee2` varchar(500) NOT NULL,
  `Percentage2` varchar(4) DEFAULT NULL,
  `Assignee3` varchar(500) NOT NULL,
  `Percentage3` varchar(4) DEFAULT NULL,
  `Assignee4` varchar(500) NOT NULL,
  `Percentage4` varchar(4) DEFAULT NULL,
  `Assignee5` varchar(500) NOT NULL,
  `Percentage5` varchar(4) DEFAULT NULL,
  `Assignee6` varchar(255) DEFAULT NULL,
  `Percentage6` varchar(255) DEFAULT NULL,
  `Assignee7` varchar(255) DEFAULT NULL,
  `Percentage7` varchar(255) DEFAULT NULL,
  `Assignee8` varchar(255) DEFAULT NULL,
  `Percentage8` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `projectsdetailtable`
--
ALTER TABLE `projectsdetailtable`
  ADD PRIMARY KEY (`ProjectID`),
  ADD UNIQUE KEY `Sl.No` (`Sl.No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `projectsdetailtable`
--
ALTER TABLE `projectsdetailtable`
  MODIFY `Sl.No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
