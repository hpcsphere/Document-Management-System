-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 23, 2019 at 02:45 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pipHunter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`username`, `password`) VALUES
('piphunteradmin', 'piphunteradmin');

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--

CREATE TABLE `useraccounts` (
  `Sl.No` int(11) NOT NULL,
  `AccountNo` varchar(20) NOT NULL,
  `AccountType` varchar(20) NOT NULL DEFAULT 'Live',
  `StartDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Validity` int(11) NOT NULL,
  `ExpiryDate` datetime DEFAULT NULL,
  `IsExpired` tinyint(4) NOT NULL DEFAULT '1',
  `Source` varchar(20) NOT NULL DEFAULT 'Manual'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `useraccounts`
--

INSERT INTO `useraccounts` (`Sl.No`, `AccountNo`, `AccountType`, `StartDate`, `Validity`, `ExpiryDate`, `IsExpired`, `Source`) VALUES
(809, '1234567', 'Live', '2016-10-20 00:00:00', 90, '2017-01-18 00:00:00', -1, 'WRCP'),
(814, '12114', 'Live', '2016-10-21 00:00:00', 10, '2016-10-31 00:00:00', -1, 'WRCP'),
(815, '000000', 'Live', '2016-11-15 00:00:00', 7, '2016-11-22 00:00:00', 1, 'WRCP'),
(817, '5295575', 'Demo', '2017-05-01 00:00:00', 7, '2017-05-08 00:00:00', -1, 'WRCP'),
(818, '557070', 'Demo', '2017-05-12 00:00:00', 8, '2017-05-20 00:00:00', -1, 'WRCP'),
(819, '007', 'Live', '2019-03-23 00:00:00', 10, '2019-04-02 00:00:00', 1, 'WRCP'),
(822, '008', 'Demo', '2019-03-23 00:00:00', 2, '2019-03-25 00:00:00', -1, 'WRCP');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `useraccounts`
--
ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`Sl.No`),
  ADD UNIQUE KEY `account_no` (`AccountNo`),
  ADD KEY `Sl.No` (`Sl.No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `useraccounts`
--
ALTER TABLE `useraccounts`
  MODIFY `Sl.No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=823;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`pipHunter`@`localhost` EVENT `SET_EXPIRY` ON SCHEDULE EVERY 5 MINUTE STARTS '2016-05-02 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE `useraccounts` SET `IsExpired`= -1 WHERE ((`ExpiryDate` IS NOT NULL) AND (`ExpiryDate` != '0000-00-00 00:00:00') AND (DATEDIFF(curDate(),`ExpiryDate`) > 0))$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
