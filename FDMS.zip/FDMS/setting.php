<?php
  session_start();
  require_once('config.php');

  $user = "";
  $email = "";
  if(isset($_SESSION['username'])){
    $user=$_SESSION['username'];
  }else{
    header("Location: login.html");
  }

?>




<!DOCTYPE html>
<html>
<head>
  <title>Document Processing and Management System</title>
  <meta charset="utf-8">
  <link rel="shortcut icon" type="image/png" href="icon.png">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/pdp.css">
  <link href="css/dropzone.css" rel="stylesheet">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/dropzone.js"></script>
 <!--  <script src="js/pdp.js"></script> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pretty-checkbox@3.0/dist/pretty-checkbox.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.css" rel="stylesheet"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.js"></script>
</head>

<style>
  .chosen-container-single .chosen-default{
    text-align: left;
  }

  .chosen-container .chosen-results {
    text-align: left;
  }
  .chosen-container {
    text-align: left;
    width: 300px ! important;
  }

  body {

    width: 100%;
  }
  
  .txt {
    color: #87CEEB;
  }

  .txt1 {
    color: green;
    display: none;
  }

  .bcdiv {
    border: 1px solid #87CEEB;
    padding: 10px;
    display: none;
  }

  .bcbt {
    background-color: #87CEEB ! important;
    border-color: #87CEEB ! important;
    width: 100%;
    border-radius: 0;
    border: 2px red ! important;
    text-align: left;
  }

  .bcdiv1 {
    border: 1px solid #87CEEB;
    padding: 10px;
    display: none;
  }

  .bcbt1 {
    background-color: #87CEEB ! important;
    border-color: #87CEEB ! important;
    width: 100%;
    border-radius: 0;
    border: 2px red ! important;
    text-align: left;
  }

  .bcdiv2 {
    border: 1px solid #87CEEB;
    padding: 10px;
    display: none;
  }

  .bcbt2 {
    background-color: #87CEEB ! important;
    border-color: #87CEEB ! important;
    width: 100%;
    border-radius: 0;
    border: 2px red ! important;
    text-align: left;
  }

  #confrmpass,#newpass,#key,#secret {
    width: 50%;
  }

  .divicon {
    float: right;
    color: white ! important;
    line-height: inherit;
  }

  .eye {
   /* position: absolute;
    margin-left: 259px;*/
    margin-top: -25px;
    color: #87CEEB ! important;
    cursor: pointer;
  }

  .eye1 {
   /* position: absolute;
    margin-left: 294px;*/
    margin-top: -25px;
    color: #87CEEB ! important;
    cursor: pointer;
  }

  .edit {
   /* position: absolute;
    margin-left: 278px;*/
    margin-top: -25px;
    color: #87CEEB ! important;
    cursor: pointer;
  }

  .edit1 {
   /* position: absolute;
    margin-left: 315px;*/
    margin-top: -25px;
    color: #87CEEB ! important;
    cursor: pointer;
  }

  .lab {
    position: absolute;
    margin-left: 145px;
    margin-top: 10px;
  }


  .lab1 {
    position: absolute;
    margin-left: 145px;
    margin-top: 24px;
  }

  .btn:focus,.btn:active {
   outline: 1px solid #2cafe4 !important;
  }

  .icondiv {
    width: 100px;
    float: right;
    margin-right: 135px;
    margin-top: -23px;
  }


</style>

 <body class="fa">
     <header style="background-color: #87CEEB;padding: 10px;position: fixed;width: 100%;height: 15px;z-index: 100;"> 
      <div style="float: right;position: relative;bottom: 12px;">
         <a href="setting.php"><i class="fa fa-cog" title="Settings" style="padding: 5px;color: white ! important;cursor: pointer;"></i></a>
         <a href="logout.php"><i class="fa fa-power-off" title="Logout" style="padding: 5px;color: white ! important;cursor: pointer;"></i></a>
       </div>
    </header> 
      <div class="container container1">
        <center> <h3>Document Processing and Management System</h3></center>
    </div><br>


    <div class="sidebar" style="height: 730px;">

        <ul class="sidebar-nav">
             <i id="navbar-toggle" class="fa fa-times menu-icon fa-2x open" aria-hidden="true" style="color: white !important;margin: 6px;margin-right: -25px;cursor: pointer;background-color: rgb(135, 206, 235) !important;width: 25px;margin-top: 0px;padding-left: 4px;position: absolute;right: 0;display: none;border-left: 1px solid white;" title="Open"></i>

            <i id="navbar-toggle" class="fa fa-arrow-left menu-icon fa-2x closem" aria-hidden="true" style="color: white !important;margin: 6px;margin-right: -25px;cursor: pointer;background-color: rgb(135, 206, 235) !important;width: 25px;margin-top: 0px;padding-left: 4px;position: absolute;right: 0;border-left: 1px solid white;font-size: 17px;height: 20px;" title="Close"></i>

             <i id="navbar-toggle" class="fa fa-bars menu-icon fa-2x closem1" id="closem1" aria-hidden="true" style="color: white !important;margin: 6px;margin-right: -25px;cursor: pointer;background-color: rgb(135, 206, 235) !important;width: 25px;margin-top: 0px;padding-left: 4px;position: absolute;right: 0;display:none ;border-left: 1px solid white;z-index: 100;" title="Close"></i>

            <li>
                <a href="./"><i class="fa fa-cloud-upload menu-icon fa-2x" aria-hidden="true" style="color: white !important;line-height: 0.2;font-size: 20px;float: ;"></i>&nbsp;&nbsp;Upload Documents</a>
                <a href="setting.php" class="active"><i class="fa fa-cog menu-icon fa-2x" aria-hidden="true" style="color: white !important;line-height: 0.2;font-size: 20px;float: ;"></i>&nbsp;&nbsp;Settings</a>
            </li>

        </ul>
    </div>


    <br><br><br><br><br>
    <div class="container col-sm-12">

      <div class="col-sm-12 paddleft" style=";padding-left: 220px;">


        <button class="btn btn-primary bcbt2">Set AWS access key
          <i class="fa fa-plus divicon"></i>
          <i class="fa fa-minus divicon" style="display:none;"></i>
         </button>

        <div class="bcdiv2">

           <form id="awsfrm">
             

                <?php
                 $sql = "SELECT * FROM Bucket_Credentials WHERE 1";
                 $result=$con->query($sql);
                 if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo'
                        <label class="lab txt">Access Key ID</label>
                         <center>
                        <input type="Password" name="key" class="form-control" placeholder="Enter Key" id="key" required style="margin-top: 15px;" autocomplete="off" value="'.$row['key'].'" disabled> </center>

                        <div class="icondiv">

                        <i class="fa fa-eye eye ey iconhover" style="font-size: 15px;"></i>
                        <i class="fa fa-eye-slash eye eys iconhover" style="display:none;font-size: 15px;"></i>&nbsp;&nbsp;
                        <i class="fa fa-edit edit iconhover" style="font-size: 15px;"></i>

                        </div>
                       
                        <label class="lab1 txt">Secret Access Key</label>
                        <center>
                        <input type="Password" name="secret" class="form-control" placeholder="Enter Secret Key" id="secret" required style="margin-top: 15px;" autocomplete="off" value="'.$row['secret'].'" disabled></center>
                          <div class="icondiv">
                          <i class="fa fa-eye eye1 ey1 iconhover" style="font-size: 15px;"></i>
                          <i class="fa fa-eye-slash eye1 eys1 iconhover" style="display:none;font-size: 15px;"></i>&nbsp;&nbsp;
                           <i class="fa fa-edit edit1 iconhover" style="font-size: 15px;"></i>
                          </div>

                        ';
                     
                    }
                  }else{

                         echo'

                        <label class="lab txt">Access Key ID</label>
                         <center>
                         <input type="Password" name="key" class="form-control" placeholder="Enter Key" id="key" required style="margin-top: 15px;" autocomplete="off">
                         <i class="fa fa-eye eye ey"></i>
                        <i class="fa fa-eye-slash eye eys" style="display:none;"></i>
                        <i class="fa fa-edit edit"></i>
                          </center>
                        <label class="lab1 txt">Secret Access Key</label>
                        <center>
                        <input type="Password" name="secret" class="form-control" placeholder="Enter Secret Key" id="secret" required style="margin-top: 15px;" autocomplete="off"></center>
                         <i class="fa fa-eye eye1 ey1"></i>
                          <i class="fa fa-eye-slash eye1 eys1" style="display:none;"></i>
                         <i class="fa fa-edit edit1"></i>

                        ';
                  }

                  ?>

              <center><button class="btn btn-primary" id="awsbtn" style="margin-top: 15px;"><i class="fa fa-check" style="color: white ! important;"></i><i class="fa fa-spinner fa-spin spin1" style="font-size: 28px;position: absolute;margin-top: -5px;display:none ; color: white ! important;margin-left: 44px;"></i>&nbsp;Save AWS access key</button>

               <p style="color: green ! important;position: absolute;left: 66%%;margin-top: -23px;display:none;" id="cc"><i class="fa fa-check"></i>&nbsp;Credentials changed successfully.</p>
            <p style="color: red ! important;position: absolute;left: 66%%;margin-top: -23px;display:none;" id="cnc"><i class="fa fa-times"></i>&nbsp;Credentials not change!</p>
            </center>
            </form>

        </div><br><br><br><br><br><br>


        <button class="btn btn-primary bcbt">Set default bucket
          <i class="fa fa-plus divicon"></i>
          <i class="fa fa-minus divicon" style="display:none;"></i>
        </button>

        <div class="bcdiv">

           <center>
           <br>
            <select data-placeholder="Select default bucket" class="chosen-select fa" tabindex="2" style="">
               <option value=""></option>
              <?php
                 $sql = "SELECT * FROM Buckets WHERE 1";
                 $result=$con->query($sql);

                  if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                      if($row['Status']=="default"){
                        echo"<option selected value='".$row['SN']."' data='".$row['Bucket_Name']."'>".$row['Bucket_Name']." ( ".$row['SN']." )</option>";
                      }else{
                         echo"<option value='".$row['SN']."' data='".$row['Bucket_Name']."'>".$row['Bucket_Name']." ( ".$row['SN']." )</option>";
                      }
                    }

                 }

                ?>
             
            </select></center><br><br>
            <center><label class="txt1">The default bucket for uploading files has been updated to <span id="bn">$BUCKET_NAME</span>.</label></center>
        </div><br><br><br><br><br><br>

         <button class="btn btn-primary bcbt1">Change password
          <i class="fa fa-plus divicon"></i>
          <i class="fa fa-minus divicon" style="display:none;"></i>
         </button>

        <div class="bcdiv1">

           <form id="chngpassfrm">
              <center><input type="Password" name="Password" class="form-control" placeholder="Enter New Password" id="newpass" required style="margin-top: 15px;">
              <input type="Password" name="Password" class="form-control" placeholder="Confirm Password" id="confrmpass" required style="margin-top: 15px;">
              <button class="btn btn-primary" id="chngpassbtn" style="margin-top: 15px;"><i class="fa fa-check" style="color: white ! important;"></i><i class="fa fa-spinner fa-spin spin" style="font-size: 28px;position: absolute;margin-top: -3px;display:none ; color: white ! important;"></i>&nbsp;Change my password</button>

               <p style="color: green ! important;position: absolute;left: 66%%;bottom: 11px;display:none;" id="pc"><i class="fa fa-check"></i>&nbsp;Password changed successfully.</p>
            <p style="color: red ! important;position: absolute;left: 66%%;bottom: 11px;display:none;" id="pnc"><i class="fa fa-times"></i>&nbsp;Password not change!</p>
            </center>
            </form>

        </div><br><br><br><br>

      </div>
  
    </div>

    <!-- Modal -->
  <div class="modal fade" id="detailsmodal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
         <center> <h4 class="modal-title" style="font-family: bold;float: left;"><b>Document Processing and Management System</b></h4></center>
        </div>
        <div class="modal-body">
           Successfully updated.
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
    <script>

  
  $("#chng").click(function(){
    $("#chngpassmdl").modal();
  });

  $("#chngpassfrm").submit(function(e){
    e.preventDefault();
    var newpass = $("#newpass").val();
    var confrmpass = $("#confrmpass").val();
    if(confrmpass !== newpass){
      $("#confrmpass").css("border","1px solid red");
    }else{
      $("#chngpassbtn").attr("disabled",true);
      $("#chngpassbtn").css("cursor","not-allowed");
      $(".spin").css("display","inherit");
      $("#confrmpass").css("border","1px solid lightgrey");
      $.post('changepwd.php',{
        'changepwd' : confrmpass,
      },function(data){
        if(data==1){
          $("#chngpassbtn").removeAttr("disabled");
          $("#chngpassbtn").css("cursor","pointer");
          $(".spin").css("display","none");
          $("#pc").fadeIn(1500).fadeOut(4000);
        }else{
          $("#chngpassbtn").removeAttr("disabled");
          $("#chngpassbtn").css("cursor","pointer");
          $(".spin").css("display","none");
          $("#pnc").fadeIn(1500).fadeOut(4000);
        }
      });
    }
  }); 

  var k = $("#key").val();
  var s = $("#secret").val();

   $("#awsfrm").submit(function(e){
    e.preventDefault();
    var key = $("#key").val();
    var secret = $("#secret").val();

    if(k!==key || s!==secret){

      k = key;
      s = secret;

      $("#awsbtn").attr("disabled",true);
      $("#awsbtn").css("cursor","not-allowed");
      $(".spin1").css("display","inherit");
      $.post('aws.php',{
        key,
        secret,
      },function(data){
        // if($.trim(data)==1){
          $("#awsbtn").removeAttr("disabled");
          $("#awsbtn").css("cursor","pointer");
          $(".spin1").css("display","none");
          $("#cc").fadeIn(1500).fadeOut(4000);
        // }else{
        //   $("#awsbtn").removeAttr("disabled");
        //   $("#awsbtn").css("cursor","pointer");
        //   $(".spin1").css("display","none");
        //   $("#cnc").fadeIn(1500).fadeOut(4000);
        // }
      });

    }
  }); 


 if(getCookie("nav")=="open"){
     var state = "expanded";
    $('.sidebar').css('margin-left', '0px');
     $(".paddleft").css({ "padding-left": "220px"});
     $(".lricon").css({ "left": "192px"}); 
     $(".closem").css("display","inline-block");
     $(".open").css("display","none");
     $(".sidebar").css("transition","none");
  }else if(getCookie("nav")=="close"){
   
    $(".sidebar").css("transition"," none");
     // var state = "minimized";
     var state = "minimized";
    $('.sidebar').css('margin-left', '-150px');
    $(".paddleft").css({ "padding-left": "70px"}); 
    $(".lricon").css({ "left": "42px"}); 
    $(".open").css("display","inline-block");
    $(".closem").css("display","none");
    $(".closem1").css("display","none");
  }else{
    $(".sidebar").css("transition"," none");
    $('.sidebar').css({'margin-left':'-202px'});
     $(".closem1").css("display","inline-block");
      $(".paddleft").css({ "padding-left": "8px"}); 
     var state = "minimized1";
   
  }

//Check if navbar is expanded or minimized and handle 
$('.closem, .closem1, .open').click(function() {
  $(".sidebar").css("transition","margin 1s");
  if($(this).hasClass("open")){
    setCookie("nav","close1");
  }else if($(this).hasClass("closem")){
    setCookie("nav","close");
  }else{
    setCookie("nav","open");
  }

  


    if (state == "expanded") {
        $('.sidebar').css('margin-left', '-150px');
        // state = "minimized";
        $(".paddleft").animate({ "padding-left": "70px"}, 1000); 
        $(".lricon").animate({ "left": "42px"}, 760); 
        $(".open").css("display","inline-block");
        $(".closem").css("display","none");
        state = "minimized";
    } else {
        if (state == "minimized") {
            state = "minimized1";

          $(".closem1").css("display","inline-block");
          $('.sidebar').css({'margin-left':'-202px'});
          $(".paddleft").animate({ "padding-left": "8px"}, 1000); 
        }else{
          $(".closem").css("display","block");
           $(".closem1").css("display","none");
           $('.sidebar').css({'margin-left':'0px'});
           $(".paddleft").animate({ "padding-left": "220px"}, 1000);
           $(".lricon").animate({ "left": "192px"}, 760); 
          
          state = "expanded";

        }
    }
})


 $(document).ready(function() {
        $(function() {
        $('.chosen-select').chosen();
        $('.chosen-select-deselect').chosen({ allow_single_deselect: true });
      });

        $("body").delegate(".active-result").addClass("fa");
});


$(".chosen-select").change(function(){

  var bcn = $(this).val();
  var bn = $(this).find(":selected").attr("data");

  console.log("bcn",bcn);
  console.log("bn",bn);

  $.post("set.php",
        {
         bcn
        }, function(data)
        {

          $("#bn").text(bn);
          $(".txt1").fadeIn(1000).fadeOut(5000);

          // $("#detailsmodal").modal();

        });

});


  function setCookie(key, value, expiry) {
        var expires = new Date();
        expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
        document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
    }

    function getCookie(key) {
        var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
        return keyValue ? keyValue[2] : null;
    }

    var pm=1;
    var pm1=1;
    var pm2=1;
    $(".bcbt").click(function(){
      $(".bcdiv").slideToggle();
      if(pm==1){
        $(this).children(".fa-plus").css("display","none");
        $(this).children(".fa-minus").css("display","inline-block");
        pm=0;
      }else{
        $(this).children(".fa-plus").css("display","inline-block");
        $(this).children(".fa-minus").css("display","none");
         pm=1;
      }

    });

     $(".bcbt1").click(function(){
      $(".bcdiv1").slideToggle();
      if(pm1==1){
        $(this).children(".fa-plus").css("display","none");
        $(this).children(".fa-minus").css("display","inline-block");
        pm1=0;
      }else{
        $(this).children(".fa-plus").css("display","inline-block");
        $(this).children(".fa-minus").css("display","none");
         pm1=1;
      }
    });

     $(".bcbt2").click(function(){
      $(".bcdiv2").slideToggle();
      if(pm2==1){
        $(this).children(".fa-plus").css("display","none");
        $(this).children(".fa-minus").css("display","inline-block");
        pm2=0;
      }else{
        $(this).children(".fa-plus").css("display","inline-block");
        $(this).children(".fa-minus").css("display","none");
         pm2=1;
      }
    });

     $(".ey").click(function(){
      $(this).css("display","none");
      $(".eys").css("display","inline-block");
      $("#key").attr("type","text");
     });

     $(".eys").click(function(){
      $(this).css("display","none");
      $(".ey").css("display","inline-block");
      $("#key").attr("type","password");
     });

      $(".ey1").click(function(){
      $(this).css("display","none");
      $(".eys1").css("display","inline-block");
      $("#secret").attr("type","text");
     });

     $(".eys1").click(function(){
      $(this).css("display","none");
      $(".ey1").css("display","inline-block");
      $("#secret").attr("type","password");
     });

     $(".edit").click(function(){

      $("#key").removeAttr("disabled");

    });

   $(".edit1").click(function(){

    $("#secret").removeAttr("disabled");

  });

    </script>
  

  </body>
  </html>