<!DOCTYPE html>
<html>
<body>

<h1> Upload Test</h1>
<?php require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;

$bucket = 'sstest20';
$keyname = 'test123.txt';
                        
$s3 = new S3Client([
    'version' => 'latest',
    'region'  => 'us-east-2',
    'credentials' => [
                            'key' => "AKIAIGNM25OQQXSBRXCA",
                            'secret' =>  "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",
                                ]
                    ]);

try {
    // Upload data.
    $result = $s3->putObject([
        'Bucket' => $bucket,
        'Key'    => $keyname,
        'Body'   => 'Hello, world00000!',
        'ACL'    => 'public-read'
    ]);

    // Print the URL to the object.
    echo $result['ObjectURL'] . PHP_EOL;
} catch (S3Exception $e) {
    echo $e->getMessage() . PHP_EOL;
}
?>

</body>
</html>

