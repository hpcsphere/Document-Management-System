<?php

	require 'vendor/autoload.php';
	require_once('config.php');

	$key = "";
 	$secret = "";

  $sql1 = "SELECT * FROM Bucket_Credentials WHERE 1";
  $result1=$con->query($sql1);
   if (mysqli_num_rows($result1) > 0) {
      while($row = mysqli_fetch_assoc($result1)) {
        $key = $row['key'];
        $secret = $row['secret'];
      }
    }

	use Aws\S3\S3Client;
	use Aws\S3\Exception\S3Exception;

	 $bucket = $_POST['bucket'];

	$s3 = (new \Aws\Sdk)->createMultiRegionS3(['version' => 'latest']);

	// Instantiate the client.
	$s3 = new \Aws\S3\S3MultiRegionClient([
            'region' => 'us-west-2',
            'version' => 'latest',
            'credentials' => [
                'key'    => $key,
                'secret' => $secret,
            ]
        ]);     

	// Use the high-level iterators (returns ALL of your objects).
	try {
	    $results = $s3->getPaginator('ListObjects', [
	        'Bucket' => $bucket,
	        '@region' => 'eu-west-1',
	    ]);

	    echo '<table class="table table-hover" id="table">
		            <thead>
		              <tr>
		                <th>File Name</th>
		                <th>Last Modified Date</th>
		                <th>Size</th>
		                <th></th>
		              </tr>
		            </thead>
		            <tbody>';

	    foreach ($results as $result) {
	        foreach ($result['Contents'] as $object) {

	            $ext = pathinfo($object['Key'], PATHINFO_EXTENSION);

	            $test=$ext;
            	
		             echo' <tr>
		                <td>';
		                
		                 if($test=="png"||$test=="jpeg"||$test=="jpg"||$test=="gif"){
			            	echo"<i class='fa fa-image iconhover' aria-hidden='true' style='font-size: 15px;'></i>&nbsp;&nbsp;&nbsp;&nbsp;";
			            }else if ($test=="txt") {
			            	echo"<i class='fa fa-file iconhover' aria-hidden='true' style='font-size: 15px;'></i>&nbsp;&nbsp;&nbsp;&nbsp;";
			            }else{
			            	echo"<i class='fa fa-folder iconhover' aria-hidden='true' style='font-size: 15px;'></i>&nbsp;&nbsp;&nbsp;&nbsp;";
			            }

			            $bckey = $object['Key'];
						$bckey = (strlen($bckey) > 50) ? substr($bckey,0,50).'...' : $bckey;

		                echo'<span class="fnhover" style="cursor:default;">'.$bckey.'</span></td>
		                <td><span style="display:none;">'. date("d-m-Y", strtotime($object['LastModified'])).'</span>'. date("d M Y h:m A", strtotime($object['LastModified'])).'</td>
		                <td>'.Size($object['Size']).'</td>



		            	<td>

		            		<i class="fa fa-info details iconhover" title="Details" aria-hidden="true" style="float: right;color: #5abee6;cursor: pointer;padding-left: 10px;margin-top: 0px;font-size: 15px;"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            	 			<i class="fa fa-trash trash iconhover" title="Delete" aria-hidden="true" style="float: right;color: #5abee6;cursor: pointer;margin-left: 10px;margin-top: -1px;font-size: 15px;"></i>&nbsp;&nbsp;
            	  			<i class="fa fa-download download iconhover" title="Download" aria-hidden="true" style="float: right;cursor: pointer;font-size: 15px;"></i>

            	  			<span style="display:none;" class="lmd">'. date("d M Y h:m A", strtotime($object['LastModified'])).'</span><span style="display:none;" class="keyn">'.$bckey.'</span><span style="display:none;" class="keyn1">'.$object["Key"].'</span><span style="display:none;" class="filesize">'.Size($object['Size']).'</span><span style="display:none;" class="filename">'.$object['Key'].'</span><span style="display:none;" class="etag">'.str_replace('"', " ", $object['ETag']).'</span><span style="display:none;" class="storageclass">'.$object['StorageClass'].'</span>

		            	</td>

		              </tr>
		            ';
	        }
	    }
	    echo '</tbody>
		         </table>';
	} catch (S3Exception $e) {
	    echo $e->getMessage() . PHP_EOL;
	}

	// Use the plain API (returns ONLY up to 1000 of your objects).
	try {
	    $objects = $s3->listObjects([
	        'Bucket' => $bucket,
	        '@region' => 'eu-west-1',
	    ]);
	    foreach ($objects['Contents']  as $object) {
	        // echo $object['Key'] . PHP_EOL;
	    }
	} catch (S3Exception $e) {
	    echo $e->getMessage() . PHP_EOL;
	}


	function Size($path)
	{
	    $bytes = $path;

	    if ($bytes > 0)
	    {
	        $unit = intval(log($bytes, 1024));
	        $units = array('B', 'KB', 'MB', 'GB');

	        if (array_key_exists($unit, $units) === true)
	        {
	            return sprintf('%d %s', $bytes / pow(1024, $unit), $units[$unit]);
	        }
	    }

	    return $bytes;
	}

?>